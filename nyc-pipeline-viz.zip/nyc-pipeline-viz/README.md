# NYC Mobility Lakehouse, visualisasi pipeline

```bash
npm install
npm run dev      # pengembangan
npm run build    # hasil di dist/
```

Semua angka ada di `src/data.js` dan berasal dari run nyata. Isi `orchestration` dan
`endToEnd` setelah Hari 6, dan ganti `meta.repo` dengan URL GitHub Anda.
