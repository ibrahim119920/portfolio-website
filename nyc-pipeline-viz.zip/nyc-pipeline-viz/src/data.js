// Semua angka di file ini berasal dari output run nyata (evidence Hari 1-5).
// Bagian yang belum dijalankan diisi null dan tampil sebagai "Belum dijalankan".

export const meta = {
  title: 'NYC Mobility Lakehouse',
  subtitle:
    'Pipeline batch idempoten Bronze, Silver, Gold untuk data Yellow Taxi NYC TLC, dibangun di Databricks dengan PySpark, SQL, dan Delta Lake.',
  env: 'Databricks Free Edition (serverless) · catalog workspace · schema nyc_mobility',
  dataset: 'NYC TLC Yellow Taxi, Januari dan Februari 2024',
  updated: '2026-11-04',
  repo: '#', // ganti dengan URL GitHub
};

export const months = ['2024-01', '2024-02'];

// Hitungan per bulan, dari profiling, output notebook, dan query verifikasi
export const counts = {
  '2024-01': { bronze: 2964624, outside: 18, silver: 2964550, rejected: 74, gold: 6949, zones: 260, days: 31 },
  '2024-02': { bronze: 3007526, outside: 15, silver: 3007504, rejected: 22, gold: 6499, zones: 254, days: 29 },
};

export const rejectReasons = {
  '2024-01': [
    ['dropoff sebelum pickup', 56],
    ['pickup di luar bulan', 18],
    ['timestamp / zona null', 0],
    ['jarak negatif', 0],
  ],
  '2024-02': [
    ['dropoff sebelum pickup', 7],
    ['pickup di luar bulan', 15],
    ['timestamp / zona null', 0],
    ['jarak negatif', 0],
  ],
};

export const stages = [
  {
    id: 'source',
    name: 'Parquet TLC',
    file: 'Unity Catalog Volume',
    kind: 'source',
    status: 'proven',
    summary: 'Satu file Parquet bulanan lengkap per batch. Bulan ditentukan dari nama file, bukan dari timestamp pickup.',
    grain: 'Satu baris per perjalanan',
    write: 'Hanya dibaca, tidak diubah',
    facts: [
      ['Baris Jan', '2.964.624'],
      ['Baris Feb', '3.007.526'],
      ['Pickup di luar bulan', '18 (Jan), 15 (Feb)'],
      ['Tipe waktu', 'timestamp_ntz'],
    ],
  },
  {
    id: 'prepare',
    name: '00_prepare_batch',
    file: 'notebook',
    kind: 'prepare',
    status: 'proven',
    summary: 'Memvalidasi parameter dan input sebelum ada yang ditulis. Gagal lebih awal, tabel tetap kosong.',
    grain: 'Tidak menulis data',
    write: 'Tanpa penulisan',
    facts: [
      ['Kasus uji', '5 (2 lolos, 3 ditolak)'],
      ['2024-1', 'ditolak: format harus YYYY-MM'],
      ['2024-13', 'ditolak: bukan bulan valid'],
      ['2024-03', 'ditolak: file tidak ditemukan'],
    ],
  },
  {
    id: 'bronze',
    name: 'Bronze',
    file: 'bronze_yellow_trips',
    kind: 'bronze',
    status: 'proven',
    summary: 'Salinan apa adanya dari sumber ditambah metadata. Baris bermasalah tetap disimpan untuk audit.',
    grain: 'Satu baris per baris sumber + source_month, source_file, ingested_at',
    write: "overwrite + replaceWhere source_month = 'YYYY-MM'",
    facts: [
      ['Total baris', '5.972.150'],
      ['Riwayat', 'v0 sampai v5'],
      ['Rerun', 'Jan x2, Feb x1'],
      ['Checksum', 'identik sebelum/sesudah'],
    ],
  },
  {
    id: 'silver',
    name: 'Silver',
    file: 'silver_yellow_trips',
    kind: 'silver',
    status: 'proven',
    summary: 'Baris yang lolos aturan kualitas, dengan kolom turunan pickup_date dan trip_duration_min.',
    grain: 'Satu baris per perjalanan valid',
    write: "overwrite + replaceWhere source_month = 'YYYY-MM'",
    facts: [
      ['Diterima', '5.972.054'],
      ['Ditolak', '96 (74 Jan, 22 Feb)'],
      ['Riwayat', 'v0 sampai v9'],
      ['Rerun Feb', 'v9, checksum identik'],
    ],
  },
  {
    id: 'gold',
    name: 'Gold',
    file: 'gold_daily_pickup_zone',
    kind: 'gold',
    status: 'proven',
    summary: 'Agregat harian per zona pickup. Jumlah trip_count harus sama dengan baris Silver.',
    grain: 'Satu baris per source_month, pickup_date, pickup_location_id',
    write: "overwrite + replaceWhere source_month = 'YYYY-MM'",
    facts: [
      ['Baris Gold', '6.949 (Jan), 6.499 (Feb)'],
      ['Rekonsiliasi', 'selisih 0 di kedua bulan'],
      ['Grain ganda', '0'],
      ['Rerun Feb', 'dua kali, checksum identik'],
    ],
  },
  {
    id: 'sql',
    name: 'Analisis SQL',
    file: 'sql/02_analysis.sql',
    kind: 'sql',
    status: 'proven',
    summary: 'Zona teratas, tren harian, dan rekonsiliasi Gold terhadap Silver. Zona masih berupa ID.',
    grain: 'Hasil query',
    write: 'Hanya membaca Gold dan Silver',
    facts: [
      ['Query', '3'],
      ['Zona teratas Jan', '132 (145.240)'],
      ['Zona teratas Feb', '161 (147.086)'],
      ['Nama zona', 'belum ada lookup'],
    ],
  },
];

// Riwayat Delta (UTC). removed > 0 berarti satu file lama diganti (rerun).
export const history = {
  bronze: [
    { v: 0, ts: '2026-10-31 04:51:59', op: 'CREATE TABLE' },
    { v: 1, ts: '2026-10-31 08:56:20', m: '2024-01', rows: 2964624, removed: 0 },
    { v: 2, ts: '2026-10-31 08:57:11', m: '2024-01', rows: 2964624, removed: 1 },
    { v: 3, ts: '2026-10-31 08:58:20', m: '2024-02', rows: 3007526, removed: 0 },
    { v: 4, ts: '2026-10-31 09:04:43', m: '2024-01', rows: 2964624, removed: 1 },
    { v: 5, ts: '2026-10-31 11:02:40', m: '2024-02', rows: 3007526, removed: 1 },
  ],
  silver: [
    { v: 0, ts: '2026-10-31 04:52:02', op: 'CREATE TABLE' },
    { v: 1, ts: '2026-10-31 11:18:25', m: '2024-01', rows: 2964550, removed: 0 },
    { v: 2, ts: '2026-11-03 17:21:14', m: '2024-02', rows: 3007504, removed: 0 },
    { v: 3, ts: '2026-11-04 03:57:10', m: '2024-02', rows: 3007504, removed: 1 },
    { v: 4, ts: '2026-11-04 03:57:39', m: '2024-01', rows: 2964550, removed: 1 },
    { v: 5, ts: '2026-11-04 03:57:57', m: '2024-01', rows: 2964550, removed: 1 },
    { v: 6, ts: '2026-11-04 03:58:11', m: '2024-02', rows: 3007504, removed: 1 },
    { v: 7, ts: '2026-11-04 03:58:25', m: '2024-02', rows: 3007504, removed: 1 },
    { v: 8, ts: '2026-11-04 03:58:51', m: '2024-02', rows: 3007504, removed: 1 },
    { v: 9, ts: '2026-11-04 04:19:59', m: '2024-02', rows: 3007504, removed: 1, proof: true },
  ],
  gold: [
    { v: 0, ts: '2026-10-31 04:52:03', op: 'CREATE TABLE' },
    { v: 1, ts: '2026-11-04 04:27:47', m: '2024-01', rows: 6949, removed: 0 },
    { v: 2, ts: '2026-11-04 04:28:10', m: '2024-02', rows: 6499, removed: 0 },
    { v: 3, ts: '2026-11-04 04:31:10', m: '2024-02', rows: 6499, removed: 1 },
    { v: 4, ts: '2026-11-04 04:31:14', m: '2024-02', rows: 6499, removed: 1 },
  ],
};

// Checksum setelah rerun (identik dengan sebelum rerun pada ketiga lapisan)
export const checksums = {
  bronze: {
    '2024-01': { n: 2964624, total: 79456384.28, distance: 10827308.4 },
    '2024-02': { n: 3007526, total: 80073615.28, distance: 11611633.16 },
  },
  silver: {
    '2024-01': { n: 2964550, total: 79454065.5, distance: 10826845.05, duration: 46286364.08 },
    '2024-02': { n: 3007504, total: 80073049.72, distance: 11611564.98, duration: 48067561.23 },
  },
  gold: {
    '2024-01': { n: 2964550, total: 79454065.5, distance: 10826845.05, duration: 46286364.08 },
    '2024-02': { n: 3007504, total: 80073049.72, distance: 11611564.98, duration: 48067561.23 },
  },
};

export const topZones = {
  '2024-01': [[132,145240],[161,143469],[237,142707],[236,136464],[162,106717],[230,106324],[186,104522],[142,104080],[138,89530],[239,88474]],
  '2024-02': [[161,147086],[237,140800],[236,134000],[132,126800],[162,105937],[230,102279],[186,100415],[142,97252],[239,90849],[163,89182]],
};

// Hanya 17 hari pertama Januari yang terlihat di hasil query (bukan seluruh 60 hari).
export const dailyPartial = [
  ['01',81011],['02',75516],['03',82424],['04',102899],['05',103174],['06',97116],
  ['07',67543],['08',80028],['09',93959],['10',94997],['11',105008],['12',103653],
  ['13',104758],['14',94419],['15',77032],['16',93051],['17',110361],
];

// Isi setelah Hari 6. null = tampil "Belum dijalankan".
export const orchestration = null;
// contoh: { form: 'Databricks Job' | 'Notebook orkestrator', tasks: [['00_prepare_batch','Berhasil'], ...] }
export const endToEnd = null;
// contoh: { janUnchanged: true, febIdentical: true }

export const limits = [
  'Dua bulan data, satu jenis dataset.',
  'Delta memberi atomic commit per tabel, bukan transaksi lintas tiga tabel. Jika Silver atau Gold gagal, Bronze mungkin sudah terbarui dan workflow bulan itu dijalankan ulang.',
  'Tidak ada ID perjalanan unik, jadi tidak ada deduplikasi. Idempotensi berarti rerun tidak menggandakan batch.',
  'Aturan awal tidak membatasi durasi: perjalanan terpanjang di Silver 9.455 menit (Jan) dan 5.672 menit (Feb).',
  'Nilai uang negatif dipertahankan. Aturan refund dan validasi domain zona belum ada.',
  'Satu writer berurutan, tidak diuji untuk run paralel.',
];
export const nextSteps = ['Lookup nama zona TLC', 'Batas durasi dan aturan refund', 'Tabel log metrik', 'Dashboard', 'CI/CD', 'Bulan dan dataset tambahan'];
