import './style.css';
import {
  meta, months, counts, rejectReasons, stages, history, checksums,
  topZones, dailyPartial, orchestration, endToEnd, limits, nextSteps,
} from './data.js';

const nf = new Intl.NumberFormat('id-ID');
const nf2 = new Intl.NumberFormat('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const monthLabel = (m) => (m === '2024-01' ? 'Januari 2024' : 'Februari 2024');

const state = { stage: 'bronze', month: '2024-01', layer: 'silver', csLayer: 'silver' };

/* ---------- Bagian halaman ---------- */

function hero() {
  const total = counts['2024-01'].bronze + counts['2024-02'].bronze;
  return `
  <header class="hero">
    <button class="theme" id="theme" aria-label="Ganti tema terang atau gelap">Tema</button>
    <p class="env">${meta.env}</p>
    <h1>${meta.title}</h1>
    <p class="lead">${meta.subtitle}</p>
    <p class="hero-count"><span class="num" data-count="${total}">0</span><span class="hero-count-label">baris perjalanan melewati pipeline, dua bulan, tanpa satu pun digandakan oleh rerun</span></p>
  </header>`;
}

function pipeline() {
  const nodes = stages.map((s, i) => `
    <button class="node ${s.kind} ${state.stage === s.id ? 'on' : ''}" data-stage="${s.id}" aria-pressed="${state.stage === s.id}">
      <span class="node-name">${s.name}</span>
      <span class="node-file">${s.file}</span>
    </button>
    ${i < stages.length - 1 ? '<span class="link" aria-hidden="true"><i></i></span>' : ''}`).join('');
  return `
  <section class="block" id="pipeline">
    <h2>Jalur data</h2>
    <p class="hint">Pilih tahap untuk melihat isi, grain, dan strategi tulisnya.</p>
    <div class="flow">${nodes}</div>
    <div id="stage-detail">${stageDetail()}</div>
  </section>`;
}

function stageDetail() {
  const s = stages.find((x) => x.id === state.stage);
  return `
  <div class="detail ${s.kind}">
    <div class="detail-main">
      <h3>${s.name} <span class="badge proven">terbukti</span></h3>
      <p>${s.summary}</p>
      <dl class="kv">
        <dt>Grain</dt><dd>${s.grain}</dd>
        <dt>Strategi tulis</dt><dd><code>${s.write}</code></dd>
      </dl>
    </div>
    <ul class="facts">
      ${s.facts.map(([k, v]) => `<li><span>${k}</span><b class="num">${v}</b></li>`).join('')}
    </ul>
  </div>`;
}

function funnel() {
  const c = counts[state.month];
  const reasons = rejectReasons[state.month];
  const max = Math.max(...reasons.map((r) => r[1]), 1);
  return `
  <section class="block" id="funnel">
    <h2>Dari baris mentah ke ringkasan harian</h2>
    <div class="seg" role="tablist" aria-label="Pilih bulan">
      ${months.map((m) => `<button role="tab" data-month="${m}" class="${state.month === m ? 'on' : ''}" aria-selected="${state.month === m}">${monthLabel(m)}</button>`).join('')}
    </div>
    <div class="steps">
      <div class="step bronze"><span>Bronze</span><b class="num">${nf.format(c.bronze)}</b><small>${c.outside} baris pickup di luar bulan tetap disimpan</small></div>
      <div class="step-arrow" aria-hidden="true">−${c.rejected}</div>
      <div class="step silver"><span>Silver</span><b class="num">${nf.format(c.silver)}</b><small>lolos aturan kualitas</small></div>
      <div class="step-arrow" aria-hidden="true">Σ</div>
      <div class="step gold"><span>Gold</span><b class="num">${nf.format(c.gold)}</b><small>baris harian per zona (${c.zones} zona, ${c.days} hari). Σ trip_count = ${nf.format(c.silver)}</small></div>
    </div>
    <div class="reject">
      <h3>Mengapa ${c.rejected} baris ditolak di Silver</h3>
      ${reasons.map(([k, v]) => `
        <div class="bar-row"><span>${k}</span>
          <div class="bar"><i style="width:${(v / max) * 100}%"></i></div>
          <b class="num">${v}</b></div>`).join('')}
      <p class="hint">Tidak ada baris yang gagal di dua aturan sekaligus, jadi jumlah per aturan sama dengan baris ditolak.</p>
    </div>
  </section>`;
}

function timeline() {
  const rows = history[state.layer].map((h) => {
    if (h.op) return `<li class="tl create"><b>v${h.v}</b><div><strong>${h.op}</strong><small>${h.ts} UTC</small></div></li>`;
    const rerun = h.removed > 0;
    return `<li class="tl ${rerun ? 'rerun' : 'load'}">
      <b>v${h.v}</b>
      <div>
        <strong>${rerun ? 'Rerun' : 'Load awal'} ${h.m}${h.proof ? ' · rerun pembuktian' : ''}</strong>
        <small>${h.ts} UTC · <code>replaceWhere source_month = '${h.m}'</code> · ${nf.format(h.rows)} baris · ${h.removed} file dihapus</small>
      </div>
    </li>`;
  }).join('');
  const note = state.layer === 'silver'
    ? 'Versi 1 sampai 8 adalah run pengembangan, termasuk kode sebelum versi final. Bukti idempotensi diambil dari v9.'
    : state.layer === 'gold'
    ? 'Februari dijalankan ulang dua kali (v3 dan v4, berjarak empat detik).'
    : 'Urutan run apa adanya: Jan, Jan, Feb, Jan, Feb.';
  return `
  <section class="block" id="history">
    <h2>Riwayat Delta: rerun hanya menukar satu bulan</h2>
    <div class="seg" role="tablist" aria-label="Pilih lapisan">
      ${['bronze', 'silver', 'gold'].map((l) => `<button role="tab" data-layer="${l}" class="${state.layer === l ? 'on' : ''} ${l}" aria-selected="${state.layer === l}">${l}</button>`).join('')}
    </div>
    <ol class="tl-list">${rows}</ol>
    <p class="hint">${note} Semua penulisan memakai predicate bulan, tidak ada overwrite tanpa predicate.</p>
  </section>`;
}

function checksumTable() {
  const l = state.csLayer;
  const data = checksums[l];
  const hasDur = l !== 'bronze';
  const head = `<tr><th>Bulan</th><th>Baris</th><th>Σ total_amount</th><th>Σ jarak (mil)</th>${hasDur ? '<th>Σ durasi (menit)</th>' : ''}<th>Sebelum vs sesudah rerun</th></tr>`;
  const body = months.map((m) => {
    const d = data[m];
    return `<tr><td>${m}</td><td class="num">${nf.format(d.n)}</td><td class="num">${nf2.format(d.total)}</td><td class="num">${nf2.format(d.distance)}</td>${hasDur ? `<td class="num">${nf2.format(d.duration)}</td>` : ''}<td><span class="badge proven">identik</span></td></tr>`;
  }).join('');
  return `
  <section class="block" id="checksum">
    <h2>Bukti idempoten: checksum sebelum dan sesudah rerun</h2>
    <div class="seg" role="tablist" aria-label="Pilih lapisan checksum">
      ${['bronze', 'silver', 'gold'].map((l) => `<button role="tab" data-cs="${l}" class="${l === state.csLayer ? 'on' : ''} ${l}" aria-selected="${l === state.csLayer}">${l}</button>`).join('')}
    </div>
    <div class="scroll"><table><thead>${head}</thead><tbody>${body}</tbody></table></div>
    <p class="hint">Gold hanya menjumlahkan Silver, jadi total, jarak, dan durasinya sama dengan Silver. Kolom yang boleh berubah saat rerun: <code>ingested_at</code>, <code>processed_at</code>, dan versi Delta.</p>
  </section>`;
}

function barChart() {
  const data = topZones[state.month];
  const max = data[0][1];
  return `
  <div class="chart">
    <h3>Sepuluh zona pickup teratas, ${monthLabel(state.month)}</h3>
    ${data.map(([z, n], i) => `
      <div class="bar-row zone"><span class="num">Zona ${z}</span>
        <div class="bar gold-bar"><i style="width:${(n / max) * 100}%"></i></div>
        <b class="num">${nf.format(n)}</b></div>`).join('')}
    <p class="hint">Zona masih berupa ID. Nama zona butuh lookup resmi TLC.</p>
  </div>`;
}

function lineChart() {
  const W = 560, H = 220, p = { l: 44, r: 12, t: 12, b: 28 };
  const vals = dailyPartial.map((d) => d[1]);
  const min = Math.min(...vals) * 0.9, max = Math.max(...vals) * 1.05;
  const x = (i) => p.l + (i / (vals.length - 1)) * (W - p.l - p.r);
  const y = (v) => p.t + (1 - (v - min) / (max - min)) * (H - p.t - p.b);
  const pts = vals.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`);
  const area = `M${x(0)},${H - p.b} L${pts.join(' L')} L${x(vals.length - 1)},${H - p.b} Z`;
  const ticks = [min, (min + max) / 2, max].map((v) => `
    <line x1="${p.l}" x2="${W - p.r}" y1="${y(v)}" y2="${y(v)}" class="grid"/>
    <text x="${p.l - 6}" y="${y(v) + 4}" text-anchor="end">${Math.round(v / 1000)}rb</text>`).join('');
  const labels = dailyPartial.map((d, i) => (i % 2 === 0 ? `<text x="${x(i)}" y="${H - 8}" text-anchor="middle">${d[0]}</text>` : '')).join('');
  const dots = dailyPartial.map((d, i) => `<circle cx="${x(i)}" cy="${y(d[1])}" r="3.5"><title>${d[0]} Jan: ${nf.format(d[1])} perjalanan</title></circle>`).join('');
  return `
  <div class="chart">
    <h3>Perjalanan per hari, 17 hari pertama Januari</h3>
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Grafik garis jumlah perjalanan harian 1 sampai 17 Januari 2024">
      ${ticks}<path d="${area}" class="area"/><polyline points="${pts.join(' ')}" class="line"/>${dots}${labels}
    </svg>
    <p class="hint">Hanya 17 hari yang tertangkap di hasil query, bukan seluruh 60 hari.</p>
  </div>`;
}

function analysis() {
  return `
  <section class="block" id="analysis">
    <h2>Hasil analisis dari Gold</h2>
    <div class="grid2">${barChart()}${lineChart()}</div>
  </section>`;
}

function orchestrationBlock() {
  const o = orchestration;
  const e = endToEnd;
  return `
  <section class="block" id="orch">
    <h2>Orkestrasi dan uji ujung ke ujung</h2>
    <div class="grid2">
      <div class="pending-card ${o ? 'done' : ''}">
        <h3>Job atau notebook orkestrator</h3>
        ${o ? `<p>${o.form}</p><ul>${o.tasks.map(([t, s]) => `<li>${t}: ${s}</li>`).join('')}</ul>`
            : '<span class="badge pending">Belum dijalankan</span><p>Workflow 00 sampai 03 berurutan belum dibuktikan.</p>'}
      </div>
      <div class="pending-card ${e ? 'done' : ''}">
        <h3>Januari, Februari, rerun Februari</h3>
        ${e ? `<p>Januari tidak berubah: ${e.janUnchanged ? 'ya' : 'tidak'}. Februari identik: ${e.febIdentical ? 'ya' : 'tidak'}.</p>`
            : '<span class="badge pending">Belum dijalankan</span><p>Rerun per lapisan sudah terbukti. Rerun satu alur penuh belum.</p>'}
      </div>
    </div>
  </section>`;
}

function limitsBlock() {
  return `
  <section class="block" id="limits">
    <h2>Batasan dan langkah berikutnya</h2>
    <ul class="limits">${limits.map((l) => `<li>${l}</li>`).join('')}</ul>
    <p class="chips">${nextSteps.map((n) => `<span>${n}</span>`).join('')}</p>
  </section>`;
}

function footer() {
  return `<footer>Diperbarui ${meta.updated} · ${meta.dataset} · <a href="${meta.repo}">Repo GitHub</a></footer>`;
}

/* ---------- Render dan interaksi ---------- */

function render() {
  document.querySelector('#app').innerHTML =
    hero() + `<main>${pipeline()}${funnel()}${timeline()}${checksumTable()}${analysis()}${orchestrationBlock()}${limitsBlock()}</main>` + footer();
  countUp();
}

function countUp() {
  const el = document.querySelector('[data-count]');
  if (!el) return;
  const target = Number(el.dataset.count);
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = nf.format(target); return; }
  const t0 = performance.now(), dur = 1400;
  const tick = (t) => {
    const k = Math.min((t - t0) / dur, 1);
    el.textContent = nf.format(Math.round(target * (1 - Math.pow(1 - k, 3))));
    if (k < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

function rerenderPart(sel, html) {
  const old = document.querySelector(sel);
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  old.replaceWith(tmp.firstElementChild);
}

document.addEventListener('click', (e) => {
  const t = e.target.closest('button');
  if (!t) return;
  if (t.id === 'theme') {
    const cur = document.documentElement.dataset.theme
      || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.dataset.theme = cur === 'dark' ? 'light' : 'dark';
  } else if (t.dataset.stage) {
    state.stage = t.dataset.stage;
    rerenderPart('#pipeline', pipeline());
  } else if (t.dataset.month) {
    state.month = t.dataset.month;
    rerenderPart('#funnel', funnel());
    rerenderPart('#analysis', analysis());
  } else if (t.dataset.layer) {
    state.layer = t.dataset.layer;
    rerenderPart('#history', timeline());
  } else if (t.dataset.cs) {
    state.csLayer = t.dataset.cs;
    rerenderPart('#checksum', checksumTable());
  }
});

render();
